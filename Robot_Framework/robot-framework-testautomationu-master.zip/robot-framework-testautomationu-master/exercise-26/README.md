## Reporting and Logging

# Purpose:
Participants will understand how to review what RobotFramework did using reports and logs it generates.

## Challenge:
Find and review the report.html and log.html files from the previous exercise.
