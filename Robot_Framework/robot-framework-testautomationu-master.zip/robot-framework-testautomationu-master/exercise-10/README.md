# Externalizing Variables

## Purpose:
The purpose of this exercise is to learn how variables can be moved to resource files

## Learning Objectives:

- Automators will be able to identify resource files
- Automators will be able to identify available variables from resource files
- Automators will use variables from resource files in a test case
- Automators will modify a test case so that its variables are moved to a resource file

## Challenges:

Move the variables to a location outside of the test file. (15 min)