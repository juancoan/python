# User Supplied Variables

## Purpose:

Learn how to create and use variables.

## Learning Objectives:

- Automators will define what a variable is and its uses
- Automators will create and use a variable
- Automators will be able to restate the block variables are used in
- Automators will be able to create a variable inline and assign a value

## Challenge:
Use variables in place of literals in test. Use a variable block if you like. (15 min)
