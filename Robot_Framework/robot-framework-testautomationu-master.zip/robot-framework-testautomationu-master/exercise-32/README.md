# Externalizing Keywords

## Purpose:
Learn how to externalize keywords

## Learning Objectives:
- Automators will be able to locate externalized keywords
- Automators will be able to move a keyword to a resource file and use it
- Given a test file and supporting files, Automators will be able to state the locations a keyword could be

## Challenge:
Create a keywor called "Add Invoice" and externalize it.