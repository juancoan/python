# Where Do Keywords Come From?

## Purpose:
The purpose of this exercise is to learn where keywords come from.

## Learning Objectives:

- Automators will be able to define what a keyword is
- Automators will be able to identify correct syntax of a keyword
- Automators will be able to use a keyword in a test script
- Automators will be able to find keywords and keyword documents

## Challenge:
Determine which Library(ies) should be included for the test to pass (10 min)

**Extra Credit:** Close the browser when the test finishes