# Importing Local Libraries

## Purpose
Participant will learn how to utilize local libraries with Robot framework

## Challenge
Create a test cases for the other operations in calculator.py

## Extra Credit
Create a test case for the 4th missing simple arthmetic operation, make the test case fail, then implement the operation in the python file.
