def add(a, b):
    return float(a) + float(b)


